from flask import Flask, request
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from marshmallow import fields
from marshmallow.exceptions import ValidationError

app = Flask(__name__)
api = Api(app)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///game.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
ma = Marshmallow(app)

# =========================
# MODELS
# =========================

class MonsterType(db.Model):
    __tablename__ = "monster_types"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)

    monsters = db.relationship("Monster", back_populates="type")


class Monster(db.Model):
    __tablename__ = "monsters"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    element = db.Column(db.String(30))
    role = db.Column(db.String(30))
    type_id = db.Column(db.Integer, db.ForeignKey("monster_types.id"))

    type = db.relationship("MonsterType", back_populates="monsters")


class Player(db.Model):
    __tablename__ = "players"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    nationality = db.Column(db.String(50))

    monster_links = db.relationship(
        "PlayerMonster",
        backref="player",
        cascade="all, delete-orphan"
    )


class PlayerMonster(db.Model):
    __tablename__ = "player_monsters"

    player_id = db.Column(db.Integer, db.ForeignKey("players.id"), primary_key=True)
    monster_id = db.Column(db.Integer, db.ForeignKey("monsters.id"), primary_key=True)
    level = db.Column(db.Integer)

    monster = db.relationship("Monster")

# =========================
# SCHEMAS
# =========================

class MonsterTypeSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = MonsterType
        load_instance = True


class MonsterSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Monster
        include_fk = True
        load_instance = True

    type = fields.Method("get_type")

    def get_type(self, obj):
        return obj.type.name if obj.type else None


class PlayerMonsterSchema(ma.Schema):
    id = fields.Integer(attribute="monster.id")
    name = fields.String(attribute="monster.name")
    element = fields.String(attribute="monster.element")
    role = fields.String(attribute="monster.role")
    level = fields.Integer()
    type = fields.Method("get_type")

    def get_type(self, obj):
        return obj.monster.type.name if obj.monster.type else None


class PlayerSchema(ma.Schema):
    id = fields.Integer()
    name = fields.String()
    nationality = fields.String()
    monsters = fields.Nested(
        PlayerMonsterSchema,
        many=True,
        attribute="monster_links"
    )

# =========================
# RESOURCES
# =========================

class MonsterTypeResource(Resource):
    def get(self, id=None):
        if id is None:
            return MonsterTypeSchema(many=True).dump(MonsterType.query.all())
        return MonsterTypeSchema().dump(MonsterType.query.get_or_404(id))

    def post(self):
        data = request.get_json()
        monster_type = MonsterTypeSchema().load(data)
        db.session.add(monster_type)
        db.session.commit()
        return MonsterTypeSchema().dump(monster_type), 201

    def put(self, id):
        monster_type = MonsterType.query.get_or_404(id)
        data = request.get_json()
        monster_type.name = data["name"]
        db.session.commit()
        return MonsterTypeSchema().dump(monster_type)

    def patch(self, id):
        monster_type = MonsterType.query.get_or_404(id)
        data = request.get_json()
        monster_type.name = data.get("name", monster_type.name)
        db.session.commit()
        return MonsterTypeSchema().dump(monster_type)

    def delete(self, id):
        monster_type = MonsterType.query.get_or_404(id)
        db.session.delete(monster_type)
        db.session.commit()
        return {"message": "Monster type deleted"}


class MonsterResource(Resource):
    def get(self, id=None):
        if id is None:
            return MonsterSchema(many=True).dump(Monster.query.all())
        return MonsterSchema().dump(Monster.query.get_or_404(id))

    def post(self):
        data = request.get_json()
        monster = MonsterSchema().load(data)
        db.session.add(monster)
        db.session.commit()
        return MonsterSchema().dump(monster), 201

    def put(self, id):
        monster = Monster.query.get_or_404(id)
        data = request.get_json()
        monster.name = data["name"]
        monster.element = data["element"]
        monster.role = data["role"]
        monster.type_id = data["type_id"]
        db.session.commit()
        return MonsterSchema().dump(monster)

    def patch(self, id):
        monster = Monster.query.get_or_404(id)
        data = request.get_json()
        monster.name = data.get("name", monster.name)
        monster.element = data.get("element", monster.element)
        monster.role = data.get("role", monster.role)
        monster.type_id = data.get("type_id", monster.type_id)
        db.session.commit()
        return MonsterSchema().dump(monster)

    def delete(self, id):
        monster = Monster.query.get_or_404(id)
        db.session.delete(monster)
        db.session.commit()
        return {"message": "Monster deleted"}


class PlayerResource(Resource):
    def get(self, id=None):
        if id is None:
            return PlayerSchema(many=True).dump(Player.query.all())
        return PlayerSchema().dump(Player.query.get_or_404(id))

    def post(self):
        data = request.get_json()

        player = Player(
            name=data["name"],
            nationality=data["nationality"]
        )

        for m in data.get("monsters", []):
            monster = Monster.query.get_or_404(m["monster_id"])
            link = PlayerMonster(
                monster=monster,
                level=m["level"]
            )
            player.monster_links.append(link)

        db.session.add(player)
        db.session.commit()
        return PlayerSchema().dump(player), 201

    def delete(self, id):
        player = Player.query.get_or_404(id)
        db.session.delete(player)
        db.session.commit()
        return {"message": "Player deleted"}

# =========================
# ROUTES
# =========================

api.add_resource(MonsterTypeResource, "/monstertype", "/monstertype/<int:id>")
api.add_resource(MonsterResource, "/monster", "/monster/<int:id>")
api.add_resource(PlayerResource, "/player", "/player/<int:id>")

# =========================
# MAIN
# =========================

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
